﻿using adapter_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter_vezbanje
{
    class Program
    {
        static void Main(string[] args)
        {
            Svinja s = new Svinja();
            Konj k = new Konj();

            s.OglasiSe();
            s.PomeriSe();
            k.OglasiSe();
            k.PomeriSe();

            Labud labud = new Labud();
            Vrabac vrabac = new Vrabac();
            Adapter adapterLabud = new Adapter(labud);
            Adapter adapterVrabac = new Adapter(vrabac);

            Console.WriteLine($"vrabac:");
            vrabac.Pevaj();
            vrabac.Leti();

            Console.WriteLine("adapterVrabac:");
            adapterVrabac.OglasiSe();
            adapterVrabac.PomeriSe();
            Console.ReadLine();
        }
    }
}
