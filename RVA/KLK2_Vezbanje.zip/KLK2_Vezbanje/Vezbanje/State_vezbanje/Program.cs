﻿using Account_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_vezbanje
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account();
            account.Deposit(500);
            Console.WriteLine(account);
            account.Withdraw(10000);
            Console.WriteLine(account);



            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
        }
    }
}
