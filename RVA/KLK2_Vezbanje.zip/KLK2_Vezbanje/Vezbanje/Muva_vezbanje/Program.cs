﻿using muva_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Muva_vezbanje
{
    class Program
    {
        static void Main(string[] args)
        {
            Client client = new Client();
            Sandwitch s = client.m_SandwitchFactory.GetSandwitch("VeggieSlider");
            s.Porudzbina(10);


            Console.WriteLine("Press enter to shutdown program");
            Console.ReadLine();
        }
    }
}
