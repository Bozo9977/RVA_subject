﻿using korisnik;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = string.Empty;

            while (true)
            {
                Console.WriteLine("Unesite Unesite =>\n i za prijavu\no za odjavu\nx kraj programa ");

                string unos = Console.ReadLine();
                switch (unos[0])
                {
                    case 'i':
                        {
                            Console.WriteLine("Username: ");
                            username = Console.ReadLine();
                            Console.WriteLine("Password: ");
                            string pass = Console.ReadLine();
                            UsersService.Instance.Prijava(username, pass);
                        }break;
                    case 'o':
                        {
                            UsersService.Instance.Odjava(username);
                            username = string.Empty;
                        }break;
                    case 'x':
                        {
                            UsersService.Instance.SaveData();
                            return;
                        }
                    default:
                        break;
                }




            }
        }
    }
}
