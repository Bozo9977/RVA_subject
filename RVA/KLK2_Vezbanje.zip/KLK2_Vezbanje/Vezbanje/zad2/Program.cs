﻿using Package1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    class Program
    {
        static Masina masina = new Masina();
        static int brojac = 0;

        static void Main(string[] args)
        {
            string unos = string.Empty;
            Console.WriteLine("n - novi orah\ne - izvrsi sve komande\nx - kraj programa");
            ConsoleKeyInfo cki = Console.ReadKey();

            while (cki.Key != ConsoleKey.X)
            {
                if (cki.Key == ConsoleKey.N)
                    GenerisiOrah();
                else if (cki.Key == ConsoleKey.E)
                    masina.IzvrsiKomande();
                else
                    Console.WriteLine("pogresan key");
                Console.WriteLine("n - novi orah\ne - izvrsi sve komande\nx - kraj programa");
                cki = Console.ReadKey();
                
            }

            Console.WriteLine($"\n\nKraj programa sa: {brojac} oraha");
            Console.ReadLine();
        }


        static void GenerisiOrah()
        {
            Orah o1 = new Orah();
            o1.ID = "Orah" + brojac.ToString();
            o1.Razbijen = (brojac % 3 == 0) ? true : false;
            Razbij kom = new Razbij(o1);
            masina.DodajKomandu(kom);
            brojac++;
            Console.WriteLine("\nOrah napravljen i komanda dodata");
        }
    }
}
