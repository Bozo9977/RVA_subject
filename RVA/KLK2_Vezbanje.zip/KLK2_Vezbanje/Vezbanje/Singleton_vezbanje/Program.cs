﻿using singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_vezbanje
{
    class Program
    {
        static void Main(string[] args)
        {

            Server s = ConfigManager.Manager().ReadServer("../../../serveri.txt");
            Console.WriteLine(s);

            Console.WriteLine("We'll change something");
            s.Ime = "MarijaServer";
            s.IPAdresa = "127.0.0.0";
            s.BrojPoziva = 400;
            s.VremeCekanja =20;
            Console.WriteLine(s);
            ConfigManager.Manager().WriteServer("../../../serveri.txt", s);

            Console.ReadLine();

        }
    }
}
