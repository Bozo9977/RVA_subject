﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("+ - povecaj temp\n- - smanji temp\nx - kraj");
            
            Alarm alarm = new Alarm();
            Console.WriteLine(alarm);
            ConsoleKeyInfo cki = Console.ReadKey();
            while (cki.Key != ConsoleKey.X)
            {
                
                if (cki.Key == ConsoleKey.Add)
                    alarm.PovecajTemperaturu();
                else if (cki.Key == ConsoleKey.Subtract)
                    alarm.SmanjiTemperaturu();
                else
                    Console.WriteLine("\nPOGRESAN TASTER!!!\n");
                cki = Console.ReadKey();

            }
            
            
        }
    }
}
