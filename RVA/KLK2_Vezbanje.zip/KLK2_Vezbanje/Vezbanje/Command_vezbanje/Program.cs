﻿using command_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_vezbanje
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            Number number = new Number();
            calculator.AddAndExecute(new AddCommand(number, 1));
            Console.WriteLine(number.Result);
            calculator.AddAndExecute(new AddCommand(number, 1));
            Console.WriteLine(number.Result);
            calculator.AddAndExecute(new AddCommand(number, 1));
            Console.WriteLine(number.Result);
            Console.WriteLine("Undoooo");
            calculator.Undo();
            Console.WriteLine(number.Result);
            calculator.Undo();
            Console.WriteLine(number.Result);
            calculator.Undo();
            Console.WriteLine(number.Result);
            calculator.Redo();
            Console.WriteLine(number.Result);
            calculator.Redo();
            Console.WriteLine(number.Result);
            calculator.Redo();
            Console.WriteLine(number.Result);

            Console.ReadLine();
        }
    }
}
