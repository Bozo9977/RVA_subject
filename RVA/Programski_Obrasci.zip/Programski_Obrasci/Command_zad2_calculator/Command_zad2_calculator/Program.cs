﻿using Command_zad_calculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_zad2_calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Number n = new Number();
            Command add = new OperationAddCommand(n, 4);
            Command subb = new OperationSubstractCommand(n, 1);
            Command div = new OperationDivideCommand(n, 3);
            Command mul = new OperationMultiplyCommand(n, 10);

            Calculator calculator = new Calculator();
            calculator.AddAndExecute(add);
            Console.WriteLine($"{n}");
            calculator.AddAndExecute(subb);
            Console.WriteLine($"{n}");
            calculator.AddAndExecute(mul);
            Console.WriteLine($"{n}");
            calculator.AddAndExecute(div);
            Console.WriteLine($"{n}");

            calculator.Undo();
            Console.WriteLine($"{n}");

            calculator.Redo();

            Console.WriteLine($"{n}");



            Console.ReadLine();
        }
    }
}
