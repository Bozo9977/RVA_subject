﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zivotinje;

namespace Adapter_zadatak_zivotinje
{
    class Program
    {
        static void Main(string[] args)
        {
            Labud l = new Labud();
            Vrabac v = new Vrabac();
            Konj k = new Konj();
            Svinja s = new Svinja();
            Adapter adapterLabud = new Adapter(l);
            Adapter adapterVrabac = new Adapter(v);

            k.OglasiSe();
            k.PomeriSe();
            s.OglasiSe();
            s.PomeriSe();
            adapterLabud.OglasiSe();
            adapterLabud.PomeriSe();
            adapterVrabac.OglasiSe();
            adapterVrabac.PomeriSe();

            Console.ReadLine();

        }
    }
}
