﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zadatak1;

namespace Command_zad1_switchLights
{
    class Program
    {
        static void Main(string[] args)
        {
            Light lamp = new Light();
            Command switchUp = new FlipUpCommand(lamp);
            Command switchDown = new FlipDownCommand(lamp);

            Switch mySwitch = new Switch();

            mySwitch.AddAndExecute(switchUp);
            mySwitch.AddAndExecute(switchDown);

            mySwitch.AddAndExecute(switchUp);
            mySwitch.AddAndExecute(switchDown);

            mySwitch.AddAndExecute(switchUp);
            mySwitch.AddAndExecute(switchDown);

            mySwitch.AddAndExecute(switchUp);
            mySwitch.AddAndExecute(switchDown);

            Console.WriteLine("*****Undo*****");
            mySwitch.Undo();
            mySwitch.Undo();
            mySwitch.Undo();


            Console.WriteLine("*****Redo*****");
            mySwitch.Redo();
            mySwitch.Redo();
            mySwitch.Redo();

            Console.ReadLine();
        }
    }
}
