﻿using ConfigManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_zad
{
    class Program
    {
        static void Main(string[] args)
        {

            Server server = ConfigManager.ConfigManager.Manager().Load("../../../serverConfig.txt");
            Console.WriteLine($"Read server: {server.IpAddress}");
            server.IpAddress = "192.168.1.1";

            ConfigManager.ConfigManager.Manager().Save(server, "../../../serverConfig.txt");
            Console.WriteLine($"Wrote server: {server.IpAddress}");

            int ip = 0;

            for(int i=0; i < 50; i++)
            {
                Server s1 = new Server() { Name = "Server" + i.ToString(), IpAddress = "192.168.0." + ip++.ToString(), Location = "Novi Sad" };
                ConfigManager.ConfigManager.Manager().Save(s1, "../../../serverConfig.txt");
                Console.WriteLine($"Wrote server: {s1.IpAddress}");
            }

            Console.WriteLine();
            Console.WriteLine();
            Server server1 = ConfigManager.ConfigManager.Manager().Load("../../../serverConfig.txt");
            Console.WriteLine($"Read server: {server1.IpAddress}");

            Console.ReadLine();
        }
    }
}
