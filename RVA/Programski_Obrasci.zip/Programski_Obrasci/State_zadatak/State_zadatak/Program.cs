﻿using Account_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_zadatak
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account();
            Console.WriteLine(account);
            account.Deposit(2600);
            Console.WriteLine(account);
            account.Withdraw(1800);
            Console.WriteLine(account);
            account.Withdraw(1000);
            Console.WriteLine(account);
            account.Deposit(10000);
            Console.WriteLine(account);


            Console.ReadLine();
        }
    }
}
