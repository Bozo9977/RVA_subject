﻿using Sendvic_zadatak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Muva_zad
{
    class Program
    {
        static void Main(string[] args)
        {

            Client client = new Client();
            SendvicFactory factory = new SendvicFactory();

            Sendvic s = factory.GetSendvic("BBQKing");
            s.Porudzbina(22);
            s = factory.GetSendvic("BBQKing");
            s.Porudzbina(56);

            Console.ReadLine();


        }
    }
}
