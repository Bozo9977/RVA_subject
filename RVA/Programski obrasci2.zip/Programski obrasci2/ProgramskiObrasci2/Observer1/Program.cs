﻿using Observer_alarm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Observer1
{
    class Program
    {
        private static readonly Random ran = new Random();

        static void Main(string[] args)
        {
            Console.WriteLine("Alarms are on!");

            MovementSensor sensor = new MovementSensor();
            sensor.Register(new Gates(sensor));
            sensor.Register(new LightAlarm(sensor));
            sensor.Register(new SoundAlarm(sensor));

            for(int i =0; i< 12; i++)
            {
                if(ran.Next(4) % 4 == 0)
                {
                    sensor.TypeOfMovement = (TypeOfMovement)ran.Next(Enum.GetNames(typeof(TypeOfMovement)).Length);
                    sensor.NotifyObservers();
                }else
                {
                    Console.WriteLine("**** no movements ****");
                }
                Thread.Sleep(1000);
            }

            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }
    }
}
