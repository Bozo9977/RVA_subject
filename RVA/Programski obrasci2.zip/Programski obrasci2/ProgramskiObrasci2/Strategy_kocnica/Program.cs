﻿using Strategy_kocenje;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy_kocnica
{
    class Program
    {
        static void Main(string[] args)
        {

            Vozilo golf = new Golf();
            Vozilo golf6 = new Golf6();
            Vozilo prikolica = new Prikolica();

            Console.WriteLine("=================================");
            golf.Koci();
            Console.WriteLine("=================================");
            golf6.Koci();
            Console.WriteLine("=================================");
            prikolica.Koci();
            Console.WriteLine("=================================");
            Console.ReadLine();
        }
    }
}
