﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(Console.WindowWidth, Console.LargestWindowHeight);
            FabrikaVoca azijska = new AzijskaFabrikaVoca();
            MediteranskaFabrikaVoca mediteranska = new MediteranskaFabrikaVoca();

            Voce azijskoSlatkoVoce = azijska.SlatkoVoce();
            Voce azijskoKiseloVoce = azijska.KiseloVoce();
            Voce mediteranskoSlatkoVoce = mediteranska.SlatkoVoce();
            Voce mediteranskoKiseloVoce = mediteranska.KiseloVoce();

            azijskoSlatkoVoce.IspisiVoce();
            azijskoKiseloVoce.IspisiVoce();
            mediteranskoSlatkoVoce.IspisiVoce();
            mediteranskoKiseloVoce.IspisiVoce();

            Console.ReadKey();
        }
    }
}
