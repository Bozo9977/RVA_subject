﻿using Celija_paket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Celija> celije = new List<Celija>();
            
            for(int i = 0; i<5; i++)
            {
                celije.Add(new JednocelijskiOrganizam()
                {
                    Naziv = "celija" +(i+1),
                    organele = new List<Organela>()
                {
                    new Organela() {Naziv="organela1", Funkcija="funkcija1" },
                    new Organela() {Naziv = "organela2", Funkcija = "funkcija2"}
                }
                });
            }

            

            Console.WriteLine("Celije:");
            foreach(var item in celije)
            {
                Console.WriteLine(item);
            }

            List<Celija> kloniraneCelije = new List<Celija>();

            foreach(var item in celije)
            {
                JednocelijskiOrganizam celija = (JednocelijskiOrganizam)item.Podeli();
                foreach (Organela o in celija.organele)
                {
                    o.Funkcija = String.Empty;
                }
                kloniraneCelije.Add(celija);
            }

            Console.WriteLine("**************************");
            foreach (Celija item in kloniraneCelije)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("**************************");
            foreach (Celija item in celije)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}
