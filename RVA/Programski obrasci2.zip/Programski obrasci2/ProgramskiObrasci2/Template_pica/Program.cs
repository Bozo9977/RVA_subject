﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_pica
{
    class Program
    {
        static void Main(string[] args)
        {
            Pica kapricoza = new Kapricoza();
            Pica novosadska = new Novosadska();
            Pica tunjevina = new Tunjevina();

            Console.WriteLine("===========================");
            kapricoza.UmesiPicu();
            Console.WriteLine("===========================");
            novosadska.UmesiPicu();
            Console.WriteLine("===========================");
            tunjevina.UmesiPicu();
            Console.WriteLine("===========================");
            Console.ReadLine();
        }
    }
}
