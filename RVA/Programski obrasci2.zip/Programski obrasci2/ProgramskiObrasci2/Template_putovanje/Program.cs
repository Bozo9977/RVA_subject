﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_putovanje
{
    class Program
    {
        static void Main(string[] args)
        {
            Putovanje prag = new Prag();
            Putovanje budimpesta = new Budimpesta();
            Putovanje bec = new Bec();
            Console.WriteLine("=================================");
            prag.Template();
            Console.WriteLine("=================================");
            bec.Template();
            Console.WriteLine("=================================");
            budimpesta.Template();
            Console.WriteLine("=================================");
            Console.ReadLine();
        }
    }
}
