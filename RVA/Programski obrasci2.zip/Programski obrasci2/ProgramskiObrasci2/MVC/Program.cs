﻿using MVC_Calculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();

            // User presses calculator buttons
            user.Compute('+', 1000);
            Console.ReadKey();
            user.Compute('-', 200);
            Console.ReadKey();
            user.Compute('/', 10);
            Console.ReadKey();
            user.Compute('*', 2);
            Console.ReadKey();
            user.Compute('*', 2);
            Console.ReadKey();
            user.Compute('/', 5);
            Console.ReadKey();

            // Undo 3 commands
            user.Undo(4);
            Console.ReadKey();

            // Redo 2 commands
            user.Redo(2);
            Console.ReadKey();

            Console.WriteLine();

            user.Compute('*', 2);
            Console.ReadKey();
            user.Compute('+', 100);
            Console.ReadKey();

            user.Undo(3);
            Console.ReadKey();
            user.Redo(1);

            Console.Write("Press any key to continue . . . ");
            Console.ReadKey(true);
        }
    }
}
