﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_kuca
{
    class Program
    {
        static void Main(string[] args)
        {
            Kuca beton = new BetonskaKuca();
            Kuca cigla = new CiglenaKuca();
            Kuca drvo = new DrvenaKuca();

            Console.WriteLine("====================================");
            beton.Izgradi();
            Console.WriteLine("====================================");
            drvo.Izgradi();
            Console.WriteLine("====================================");
            cigla.Izgradi();
            Console.WriteLine("====================================");
            Console.ReadLine();
        }
    }
}
