﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Weather_observer;

namespace Observer
{
    class Program
    {
        
        private static readonly Random ran = new Random();

        private static WeatherCondition GetCondition()
        {
            return (WeatherCondition)ran.Next(Enum.GetNames(typeof(WeatherCondition)).Length);
        }

        private static int GetTemperature()
        {
            return ran.Next(40);
        }

        private static void UpdateWeather(Weather w)
        {
            w.Condition = GetCondition();
            w.CurrentTemperature = GetTemperature();
            w.MinTemperature = w.CurrentTemperature - ran.Next(10);
            w.MaxTemperature = w.CurrentTemperature + ran.Next(10);
        }

        public static void Main(string[] args)
        {
            Console.WriteLine("Weather!");

            Weather weather = new Weather();
            weather.Register(new TextObserver());
            weather.Register(new PictureObserver());

            for (int i = 0; i < 10; i++)
            {
                UpdateWeather(weather);
                weather.NotifyObservers();
                Thread.Sleep(500);
            }

            Console.Write("Press any key to continue . . . ");
            Console.ReadKey(true);
        }
    }
    
}
