﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            Machine m = new Machine();
            while (true)
            {
                Console.WriteLine("T-Tea");
                Console.WriteLine("K-Kafa");
                Console.WriteLine("C-Cappucino");
                Console.WriteLine("X-EXIT");

                ConsoleKeyInfo res = Console.ReadKey();

                if (res.Key == ConsoleKey.T)
                {
                    Console.WriteLine();
                    m.Tea();
                }
                else if (res.Key == ConsoleKey.C)
                {
                    Console.WriteLine();
                    m.Cappuchino();
                }
                else if (res.Key == ConsoleKey.K)
                {
                    Console.WriteLine();
                    m.Coffe();
                }
                else if (res.Key == ConsoleKey.X)
                {
                    return;
                }
                else
                {
                    Console.WriteLine("Error command!");
                }
            }
        }
    }
}
