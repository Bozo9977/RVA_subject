﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Cell> list = new List<Cell>()
            {
                new CellOrganism("pera1")
                {
                    organelle =new List<Organelle>()
                    {
                        new Organelle("o1","l1"),
                        new Organelle("o2","l2")
                    }
                },
                new CellOrganism("pera2")
                {
                    organelle =new List<Organelle>()
                    {
                        new Organelle("o3","l3"),
                        new Organelle("o4","l4")
                    }
                },
                new CellOrganism("pera3")
                {
                    organelle =new List<Organelle>()
                    {
                        new Organelle("o5","l5"),
                        new Organelle("o6","l6")
                    }
                }
            };

            Console.WriteLine("--------------------OLD------------------------------");
            Print(list);
            Console.WriteLine("-----------------------------------------------------");

            List<Cell> newList = new List<Cell>();

            foreach (var item in list)
            {
                newList.Add(item.Clone());
            }

            foreach (var item in newList)
            {
                foreach (var it in (item as CellOrganism).organelle)
                {
                    it.LatinName += "__new";
                }
            }


            Console.WriteLine("--------------------NEW------------------------------");
            Print(newList);
            Console.WriteLine("-----------------------------------------------------");

            Console.WriteLine("--------------------OLD------------------------------");
            Print(list);
            Console.WriteLine("-----------------------------------------------------");



            Console.ReadLine();


        }

        private static void Print(List<Cell> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item.LatinName+" Cell");
                foreach (var it in (item as CellOrganism).organelle)
                {
                    Console.WriteLine("\t"+it.LatinName+"  Organelle");
                }
            }
        }
    }
}
