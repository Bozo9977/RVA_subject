﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            Message msg = new Message(false, "Zdravo ja sam Vuk.");

            msg.Send("EMAIL", "", "");
            msg.Send("EMAIL", "pera", "mika");

            msg.Important = true;
            msg.Send("LINKEDIN", "", "");
            msg.Send("LINKEDIN", "pera", "pera");

            Console.ReadLine();
        }
    }
}
