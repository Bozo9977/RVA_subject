﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            AbstractFactory facotry = new HondaFactory();

            var cbr = facotry.SportMoto();
            var gw = facotry.NormalMoto();

            cbr.Show();
            gw.Show();

            facotry = new DucatiFactory();

            cbr = facotry.SportMoto();
            gw = facotry.NormalMoto();

            cbr.Show();
            gw.Show();

            Console.ReadLine();

        }
    }
}
