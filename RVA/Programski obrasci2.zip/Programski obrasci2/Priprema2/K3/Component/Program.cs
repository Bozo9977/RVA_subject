﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            AbstractFactory g = new GoogleFactory();            
            AbstractFactory m = new MicrosoftFacotry();

            Button gb = g.GenerateButton();
            gb.Click();

            Button mb = m.GenerateButton();
            mb.Click();

            Console.ReadLine();
        }
    }
}
