﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            WeatherStation weather = new WeatherStation();
            IObserver text = new Text(weather);
            IObserver graph = new Graphic(weather);

            weather.Register(text);
            weather.Register(graph);

            weather.Temperature = 1;
            weather.Temperature = 20;

            weather.UnRegister(graph);

            weather.Temperature = 15;

            Console.ReadLine();

        }
    }
}
