﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("p-Pesnica");
                Console.WriteLine("m-Mac");
                Console.WriteLine("b-Buzdovan");
                Console.WriteLine("x-Izlaz");
                Console.Write(">>");

                string op = Console.ReadLine();
                if (op.ToLower().Equals("x"))
                    return;
                Console.Write("Meta Health:");
                int health = Int32.Parse(Console.ReadLine());

                Meta meta = new Meta(health);
                Ratnik r = new Ratnik();
                r.Napad(op, meta);
            }
        }
    }
}
