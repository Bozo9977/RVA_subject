﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IED
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person(22, Gender.MALE, 194, 115);
            Console.WriteLine($"Result HB:{p.Calculate(Algorithm.HB)}");
            Console.WriteLine($"Result RS:{p.Calculate(Algorithm.RS)}");
            Console.ReadLine();
        }
    }
}
