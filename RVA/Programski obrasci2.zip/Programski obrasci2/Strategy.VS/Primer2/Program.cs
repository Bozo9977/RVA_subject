﻿using Primeri.Primer2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primer2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Bob = new Employee("Bob");
            Bob.SetDuty(new Teacher());
            Bob.SetPaymentStrategy(new HourlyPay(500));
            Bob.HoursWorked = 160;

            Employee Alice = new Employee("Alice");
            Alice.SetPaymentStrategy(new SalaryPay(100000));
            Alice.SetDuty(new Executive());
            Alice.HoursWorked = 160;

            Employee MrGoodForNothing = new Employee("Mr. GoodforNothing");
            MrGoodForNothing.SetPaymentStrategy(new HourlyPay(500));
            MrGoodForNothing.SetDuty(new Salesman());
            MrGoodForNothing.HoursWorked = 0;

            List<Employee> employees = new List<Employee>(3) { Bob, Alice, MrGoodForNothing };

            employees.ForEach(employee => 
            {
               Console.Write("Employee {0} is performing his/her duty: ", employee.Name);
               employee.PerformDuty();
               int pay = employee.CalculatePay();
               Console.WriteLine("{0} earned {1}{2}", employee.Name, pay, Environment.NewLine);
            });

            Console.ReadKey();
        }
    }
}
