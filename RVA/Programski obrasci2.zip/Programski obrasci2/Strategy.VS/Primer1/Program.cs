﻿using Primeri.Primer1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primer1
{
    class Program
    {
        static void Main(string[] args)
        {
            Vehicle trailer = new Trailer();
            Vehicle golf1 = new VWGolf1();
            Vehicle golf6 = new VWGolf6();

            List<Vehicle> vehicles = new List<Vehicle>(3) { trailer, golf1, golf6 };

            vehicles.ForEach(vehicle => { vehicle.ApplyBrake(); });

            Console.ReadKey();

        }
    }
}
