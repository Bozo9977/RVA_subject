﻿using Primeri.Primer3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primer3
{
    class Program
    {
        static void Main(string[] args)
        {
            float value1 = 5;
            float value2 = 25;
            CalculateContext calculateContext = new CalculateContext();
            
            calculateContext.SetStrategy(new Multiplication());            
            float multiplicate = calculateContext.Calculate(value1, value2);
            Console.WriteLine("{0} * {1} = {2}", value1, value2, multiplicate);


            calculateContext.SetStrategy(new Substraction());
            float substract = calculateContext.Calculate(5, 25);
            Console.WriteLine("{0} - {1} = {2}", value1, value2, substract);

            Console.ReadKey();

        }
    }
}
